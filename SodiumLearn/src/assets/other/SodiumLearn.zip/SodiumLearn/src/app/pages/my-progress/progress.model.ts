export interface Progress {
  id: number;
  task: string;
  progress: number;
}
