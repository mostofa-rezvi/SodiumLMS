export interface Resource {
  id: number;
  title: string;
  description: string;
  image: string;
  link: string;
}
