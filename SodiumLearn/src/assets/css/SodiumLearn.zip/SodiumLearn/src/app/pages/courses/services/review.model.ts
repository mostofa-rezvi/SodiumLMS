export interface Review {
  id: number;
  name: string;
  designation: string;
  rating: number;
  review: string;
  image: string;
  date: string;
}