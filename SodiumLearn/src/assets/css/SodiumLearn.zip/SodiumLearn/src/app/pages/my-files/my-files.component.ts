import { Component } from '@angular/core';

@Component({
  selector: 'app-my-files',
  templateUrl: './my-files.component.html',
  styleUrl: './my-files.component.css'
})
export class MyFilesComponent {

}
